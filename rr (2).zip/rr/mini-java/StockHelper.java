import java.util.LinkedHashMap;
import java.util.Map;

public class StockHelper {
    public static void main(String[] args) {
        Map<String, String> trend = new LinkedHashMap<>();
        trend.put("AAPL", "Bullish");
        trend.put("MSFT", "Bullish");
        trend.put("GOOGL", "Neutral");
        trend.put("TSLA", "Volatile");

        for (Map.Entry<String, String> e : trend.entrySet()) {
            System.out.println(e.getKey() + " -> " + e.getValue());
        }
    }
}
