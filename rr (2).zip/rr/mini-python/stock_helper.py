import json
import math
import random

stocks = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA"]


def series(symbol: str, n: int = 20) -> list[float]:
    random.seed(sum(ord(c) for c in symbol))
    p = random.uniform(90, 220)
    out = []
    for i in range(n):
        p += (random.random() - 0.45) * 8 + math.sin(i / 4)
        out.append(round(max(10, p), 2))
    return out


if __name__ == "__main__":
    data = {s: series(s) for s in stocks}
    print(json.dumps(data))
