package com.stockapp.web;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class StockAnalysisService {

    private static final Map<String, StockInsight> INSIGHTS = Map.of(
            "AAPL", new StockInsight("AAPL", "Bullish", "High", "Strong product ecosystem and stable growth."),
            "MSFT", new StockInsight("MSFT", "Bullish", "High", "Cloud and AI demand keeps momentum strong."),
            "GOOGL", new StockInsight("GOOGL", "Neutral", "Medium", "Advertising remains strong with mixed macro pressure."),
            "AMZN", new StockInsight("AMZN", "Bullish", "Medium", "Retail efficiency and cloud performance drive upside."),
            "TSLA", new StockInsight("TSLA", "Volatile", "Medium", "Rapid innovation but higher price sensitivity."),
            "NVDA", new StockInsight("NVDA", "Bullish", "High", "Leading AI hardware demand supports trend.")
    );

    public List<String> allStocks() {
        return INSIGHTS.keySet().stream().sorted().toList();
    }

    public StockInsight insightFor(String symbol) {
        return INSIGHTS.getOrDefault(symbol.toUpperCase(Locale.ROOT),
                new StockInsight(symbol.toUpperCase(Locale.ROOT), "Unknown", "Low", "No model insight available."));
    }

    public String generateChartPath(String symbol) throws IOException, InterruptedException {
        String normalizedSymbol = symbol.toUpperCase(Locale.ROOT);
        Path scriptPath = Path.of("src", "main", "resources", "python", "generate_chart.py");
        Path outputPath = Path.of("src", "main", "resources", "generated-charts", normalizedSymbol + ".svg");

        ProcessBuilder processBuilder = new ProcessBuilder(
                "python",
                scriptPath.toString(),
                normalizedSymbol,
                outputPath.toString()
        );
        processBuilder.directory(new File("."));
        processBuilder.redirectErrorStream(true);

        Process process = processBuilder.start();
        StringBuilder processOutput = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                processOutput.append(line);
            }
        }
        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IOException("Python chart generation failed for " + normalizedSymbol + ": " + processOutput);
        }
        return "/charts/" + normalizedSymbol + ".svg";
    }
}
