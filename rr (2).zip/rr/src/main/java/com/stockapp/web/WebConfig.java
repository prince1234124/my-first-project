package com.stockapp.web;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String chartDir = Path.of("src", "main", "resources", "generated-charts")
                .toAbsolutePath()
                .toUri()
                .toString();
        registry.addResourceHandler("/charts/**")
                .addResourceLocations(chartDir);
    }
}
