package com.stockapp.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockAnalysisWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(StockAnalysisWebApplication.class, args);
    }
}
