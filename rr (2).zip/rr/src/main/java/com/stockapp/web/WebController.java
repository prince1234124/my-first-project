package com.stockapp.web;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WebController {

    private final StockAnalysisService stockAnalysisService;

    public WebController(StockAnalysisService stockAnalysisService) {
        this.stockAnalysisService = stockAnalysisService;
    }

    @GetMapping("/")
    public String root() {
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("loginForm", new LoginForm());
        return "login";
    }

    @PostMapping("/login")
    public String doLogin(@Valid @ModelAttribute("loginForm") LoginForm loginForm,
                          BindingResult result,
                          HttpSession session,
                          Model model) {
        if (result.hasErrors()) {
            return "login";
        }
        if (!"admin".equals(loginForm.getUsername()) || !"admin123".equals(loginForm.getPassword())) {
            model.addAttribute("errorMessage", "Invalid username or password");
            return "login";
        }
        session.setAttribute("loggedInUser", loginForm.getUsername());
        return "redirect:/home";
    }

    @GetMapping("/home")
    public String home(@RequestParam(name = "symbol", required = false, defaultValue = "AAPL") String symbol,
                       HttpSession session,
                       Model model) {
        if (session.getAttribute("loggedInUser") == null) {
            return "redirect:/login";
        }

        model.addAttribute("username", session.getAttribute("loggedInUser"));
        model.addAttribute("stocks", stockAnalysisService.allStocks());
        model.addAttribute("selectedSymbol", symbol);
        model.addAttribute("insight", stockAnalysisService.insightFor(symbol));

        try {
            model.addAttribute("chartPath", stockAnalysisService.generateChartPath(symbol));
            model.addAttribute("chartError", null);
        } catch (Exception ex) {
            model.addAttribute("chartError", "Could not generate chart right now.");
        }
        return "home";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
