package com.stockapp.web;

public record StockInsight(String symbol, String trend, String confidence, String note) {
}
