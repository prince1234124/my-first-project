import math
import random
import sys
from pathlib import Path


def stock_seed(symbol: str) -> int:
    return sum(ord(c) for c in symbol)


def generate_prices(symbol: str, points: int = 40) -> list[float]:
    random.seed(stock_seed(symbol))
    base = random.uniform(80, 280)
    prices = [base]
    for i in range(1, points):
        drift = math.sin(i / 5.0) * random.uniform(0.2, 1.8)
        change = random.uniform(-4.0, 5.5) + drift
        next_price = max(10.0, prices[-1] + change)
        prices.append(next_price)
    return prices


def to_svg(symbol: str, prices: list[float], output_path: Path) -> None:
    width, height = 940, 440
    padding = 45
    chart_w = width - 2 * padding
    chart_h = height - 2 * padding

    min_price = min(prices)
    max_price = max(prices)
    span = max(max_price - min_price, 1)

    points = []
    for index, price in enumerate(prices):
        x = padding + index * (chart_w / (len(prices) - 1))
        y = padding + (max_price - price) / span * chart_h
        points.append((x, y))

    polyline = " ".join(f"{x:.1f},{y:.1f}" for x, y in points)
    last_price = prices[-1]

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0%" stop-color="#050c1b"/>
    <stop offset="100%" stop-color="#162f5a"/>
  </linearGradient>
  <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
    <stop offset="0%" stop-color="#66f3ff"/>
    <stop offset="100%" stop-color="#9dffb6"/>
  </linearGradient>
</defs>
<rect width="100%" height="100%" fill="url(#bg)"/>
<text x="45" y="32" fill="#e4ecff" font-size="22" font-family="Arial">Stock Analysis - {symbol}</text>
<text x="45" y="58" fill="#9bb6df" font-size="14" font-family="Arial">Simulated trend curve rendered by Python</text>
<line x1="{padding}" y1="{padding}" x2="{padding}" y2="{height - padding}" stroke="#5070a8" stroke-width="1"/>
<line x1="{padding}" y1="{height - padding}" x2="{width - padding}" y2="{height - padding}" stroke="#5070a8" stroke-width="1"/>
<polyline fill="none" stroke="url(#lineGradient)" stroke-width="4" points="{polyline}"/>
<circle cx="{points[-1][0]:.1f}" cy="{points[-1][1]:.1f}" r="5" fill="#ffd480"/>
<text x="{points[-1][0] + 10:.1f}" y="{points[-1][1] - 10:.1f}" fill="#ffd480" font-size="13" font-family="Arial">${last_price:.2f}</text>
</svg>"""

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(svg, encoding="utf-8")


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: python generate_chart.py <SYMBOL> <OUTPUT_FILE>")
        return 1

    symbol = sys.argv[1].strip().upper()
    output_file = Path(sys.argv[2])
    prices = generate_prices(symbol)
    to_svg(symbol, prices, output_file)
    print(f"Chart generated for {symbol}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
