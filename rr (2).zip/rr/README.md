# Stock Market Analysis Website (HTML First)

This version is mainly HTML and works directly in the browser.

## Main App

- Open `index.html` directly in your browser.
- Login credentials:
  - Username: `admin`
  - Password: `admin123`

## Tech Split

- Main part: `index.html`
- Small CSS part: `styles.css`
- Small Python helper: `mini-python/stock_helper.py`
- Small Java helper: `mini-java/StockHelper.java`

## Optional Helpers

- Run Python helper:
  - `python mini-python/stock_helper.py`
- Run Java helper:
  - `javac mini-java/StockHelper.java && java -cp mini-java StockHelper`
